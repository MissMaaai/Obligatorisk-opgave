﻿
namespace ObligatoriskOpgDel5
{
    public class Command
    {
        public string Method { get; set; }
        public int Num1 { get; set; }
        public int Num2 { get; set; }

        public Command(int num1, int num2, string method)
        {
            Method = method;
            Num1 = num1;
            Num2 = num2;
        
        }

        public Command()
        {
        }

        public override string ToString()
        {
            return $"{{{nameof(Method)}={Method}, {nameof(Num1)}={Num1.ToString()}, {nameof(Num2)}={Num2.ToString()}}}";
        }

        public void RandomNumbers()
        {
           var result = Random.Shared.Next(Num1, Num2); // finder et tal mellem
            Console.WriteLine("Random number is: " + result);
        }

        public void AddNumbers()
        {
            var result = Num1 + Num2;
            Console.WriteLine("Added result is: " + result);
        }

        public void Subtract()
        {
            var result = Num1 - Num2;
            Console.WriteLine("Subtract result is: " + result);
        }

    }
}
