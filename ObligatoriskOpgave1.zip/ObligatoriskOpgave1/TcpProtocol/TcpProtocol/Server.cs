﻿using System.Net;
using System.Net.Sockets;

namespace TcpProtocol
{
    public class Server
    {
        private TcpListener _listener;

        public void StartServer()
        {
            _listener = new TcpListener(IPAddress.Any, 12000);

            _listener.Start(); // kører serven for at lytte efter client forbindelser

            Console.WriteLine("Server is started!");

            while (true) //betyder at serveren kører uendeligt og venter på klientforbindelse
            {
                using var _client = _listener.AcceptTcpClient(); // denne bruges til at kalde på TcpClient og accepterer en klient,
                                                       // når en client opretter forbindelsen oprettes en ny tcpClient der repræsenterer forbindelsen

                using var StreamReader = new StreamReader(_client.GetStream()); // denne bliver lavet for at kunne læse data fra clientens netværkstream. Bruger using for at frigøre ressourcer når de er færdig med at blive brugt, den afslutter også blokken, derfor bruger jeg ikke client.close()
                using var StreamWriter = new StreamWriter(_client.GetStream()) { AutoFlush = true }; // streamwriter bruges til at skrive data til klienten.
                                                                                               // auto flush sletter efter læsning af data atutomatisk, hvilket betyder data sendes med det samme

                StreamWriter.WriteLine("Choose commando: (Random, Add or Subtract)");//besked til client
                //Console.WriteLine($"Client is ready to receive");

                var message1FromClient = StreamReader.ReadLine();

                while (true)
                {
                    if (message1FromClient.ToLower() == "random")
                    {
                        StreamWriter.WriteLine("Insert two numbers with a space in between, like this: 1 15 ");
                        var message2FromClient = StreamReader.ReadLine(); //læser de to tal fra klienten

                        var splitString = message2FromClient?.Split(" ");    // denne metode bruges til at sikre, det klienten skriver er der en mellemrum mellem tallene
                                                                              // denne tekststreng indeholder tal, men er ikke tal endnu, derfor skal de konventeres til tal
                        int[] numbers = new int[2];
                        numbers = [ Convert.ToInt32(splitString[0]), Convert.ToInt32(splitString[1])]; //Her bliver tekststreng konventeret til tal i et array hvor de kan blive gemt

                        var randomNumber = Random.Shared.Next(numbers.Min(), numbers.Max()); // tager random nummer i intervallet fra mi, max
                        StreamWriter.WriteLine($"Random number is: {randomNumber}");
                    }
                    if (message1FromClient.ToLower() == "add")
                    {
                        StreamWriter.WriteLine("Insert two numbers with a space in between, like this: 1 15 ");
                        var message2FromClient = StreamReader.ReadLine(); 

                        var splitString = message2FromClient?.Split(" ");   
                        int[] numbers = new int[2];
                        numbers = [Convert.ToInt32(splitString[0]), Convert.ToInt32(splitString[1])];

                        var addedNumbers = numbers.Min() + numbers.Max();  
                        StreamWriter.WriteLine($"Added numbers is: {addedNumbers}");
                    }
                    if (message1FromClient.ToLower() == "subtract")
                    {
                        StreamWriter.WriteLine("Insert two numbers with a space in between, like this: 1 15 ");
                        var message2FromClient = StreamReader.ReadLine(); 

                        var splitString = message2FromClient?.Split(" ");    
                        int[] numbers = new int[2];
                        numbers = [Convert.ToInt32(splitString[0]), Convert.ToInt32(splitString[1])];

                        var subtractedNumbers = numbers.First() - numbers.Last();
                        StreamWriter.WriteLine($"The result is: {subtractedNumbers}");
                    }
                }
            }
        } 
    } 
}
