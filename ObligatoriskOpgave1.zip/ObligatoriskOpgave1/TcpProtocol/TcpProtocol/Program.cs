﻿using System.Net.Security;
using TcpProtocol;

var server = new Server();
server.StartServer(); 