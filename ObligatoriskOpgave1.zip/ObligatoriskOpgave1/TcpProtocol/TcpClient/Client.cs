﻿using System.Net;
using System.Net.Sockets;

namespace TcpProtocol
{
    public class Client
    {
        //public Client()
        //{
        //    StartClient();
        //}
        public void StartClient()
        {
            var ipEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 12000); //parse brugs til at kunne komme in i porten
            using var client = new TcpClient();
            client.Connect(ipEndPoint);

            Console.WriteLine($"Client connected: {client.Connected}");

            var streamReader = new StreamReader(client.GetStream());
            var streamWriter = new StreamWriter(client.GetStream());
            streamWriter.AutoFlush = true;

            while (true)
            {
                Console.WriteLine(streamReader.ReadLine());

                var inputText = Console.ReadLine();
                streamWriter.WriteLine(inputText);

                var message = streamReader.ReadLine();
                Console.WriteLine(message);

                var numbers = Console.ReadLine();
                streamWriter.WriteLine(numbers);

            }

        }

    }
}
