﻿using TcpProtocol;

var client = new Client();
client.StartClient();

